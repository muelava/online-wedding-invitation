let submitBtn = document.querySelector('section.reservation form:nth-of-type(2) input:last-child')

submitBtn.addEventListener('click', event => {
    event.preventDefault()
})